
console.log('TypeScript entry point ejecutado');
const app = document.getElementById('app');
if (app) app.textContent = 'App inicial cargada';
